SHARDA BOUTIQUE – COMPLETE APP

Features:
1. Customer List + search.
2. Same Name + Mobile number type karte hi existing customer suggestions; exact match par customer open.
3. Existing customer ke andar New Order add hota hai; old orders delete/overwrite nahi hote.
4. Tailoring garments: garment, delivery date, amount, photo, measurements, extra measurements, notes.
5. Alteration: amount, delivery date, photo, size/measurements, notes.
6. Grand Total/Advance/Balance.
7. Delivery reminder: delivery date se 2 din pehle active; Notification ON, 1-hour snooze/push, Band, Done.
8. Google Drive backup & load via OAuth Client ID.
9. PWA install support.

Important:
- Google Drive ke liye HTTPS GitHub Pages aur Google OAuth Client ID zaroori hai.
- Browser notification permission ON karna hoga.
- Background alarms browser/device support par depend karte hain; app/browser active hone par reminder checker reliably chalta hai.
