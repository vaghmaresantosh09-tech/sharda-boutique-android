package com.shardaboutique.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val notificationReq = 20
    private val fileChooserReq = 101
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        WebView.setWebContentsDebuggingEnabled(false)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.databaseEnabled = true
        web.settings.setSupportZoom(false)
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                    return true
                }
                return false
            }
        }

        // Enable <input type="file"> photo/file selection inside Android WebView.
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "image/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    startActivityForResult(intent, fileChooserReq)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    Toast.makeText(this@MainActivity, "Photo select nahi ho paya", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }

        web.addJavascriptInterface(AndroidBridge(this), "AndroidApp")
        web.loadUrl("file:///android_asset/index.html")
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationReq)
        }
    }

    @Deprecated("Deprecated in Android API 33, kept for compatibility with this simple project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserReq) {
            val callback = filePathCallback
            filePathCallback = null
            val results = if (resultCode == RESULT_OK && data != null) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else {
                null
            }
            callback?.onReceiveValue(results)
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    class AndroidBridge(private val context: Context) {
        @JavascriptInterface fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        @JavascriptInterface fun scheduleReminder(id: String, customer: String, garment: String, triggerMillis: Long) {
            ReminderReceiver.schedule(context, id, customer, garment, triggerMillis)
        }
        @JavascriptInterface fun cancelReminder(id: String) = ReminderReceiver.cancel(context, id)
        @JavascriptInterface fun openNotificationSettings() {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply { putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName) }
            context.startActivity(intent)
        }
    }
}
