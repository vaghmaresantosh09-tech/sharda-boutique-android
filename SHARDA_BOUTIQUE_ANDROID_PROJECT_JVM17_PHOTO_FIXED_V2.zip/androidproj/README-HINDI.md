# SHARDA BOUTIQUE — Android App

यह Android Studio project है। इसमें मौजूदा SHARDA BOUTIQUE tailoring app को Android WebView के अंदर चलाया गया है, इसलिए Customer List, multiple orders, measurements, photo, amount/advance/balance, bill/share, alteration और existing web-app features साथ रहते हैं।

## Android में जोड़ा गया
- Android notification permission
- Delivery reminder का native background alarm/notification
- 2 दिन पहले सुबह 9 बजे reminder schedule
- 1 घंटे Snooze
- Band / Done पर native alarm cancel
- Offline local app data (WebView localStorage)

## Build
1. Android Studio में यह पूरा folder खोलें।
2. Gradle sync होने दें।
3. `app` select करके Run करें, या Build > Build APK(s) करें।
4. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## Google Drive
मौजूदा HTML में Google Drive वाला हिस्सा मौजूद है, लेकिन Android WebView में Google OAuth browser-जैसा व्यवहार हर device पर समान नहीं होता। Reliable native Drive login/sync के लिए अगला version native Google Sign-In + Drive API जोड़ सकता है।
